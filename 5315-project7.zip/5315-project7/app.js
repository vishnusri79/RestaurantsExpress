/******************************************************************************ITE5315 – ProjectI declare that this assignment is my own work in accordance with Humber AcademicPolicy.No part of this assignment has been copied manually or electronically from any othersource(including web sites) or distributed to other students.Name:vishnu vardhan pendem Student ID:n01583961 Date:18th april******************************************************************************/
require("dotenv").config();
const express = require('express');
const bodyParser = require('body-parser');
const { check, validationResult } = require('express-validator');
const db = require('./utils/db');
const exphbs = require('express-handlebars');
const User = require('./models/User');//new
const jwt = require('jsonwebtoken');


const app = express();
const port = process.env.PORT || 8000;
const users = [];//new

app.engine('.hbs', exphbs.engine({ extname: '.hbs' , defaultLayout: false}));
app.set('view engine', '.hbs');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));

const { generateAccessToken } = require('./utils/authUtils');



const MONGODB_URI = process.env.DB_CONNECTION_STRING;

// Initialize MongoDB connection and models
db.initialize(MONGODB_URI)
    .then(() => {
        console.log('Database initialized');
        app.listen(port, () => {
            console.log(`Server is running on port ${port}`);
        });
    })
    .catch(error => {
        console.error('Failed to initialize database:', error);
    });

    function authenticateToken(req, res, next) {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        if (token == null) return res.sendStatus(401);
    
        jwt.verify(token, 12345, (err, user) => {
            if (err) return res.sendStatus(403);
            req.user = user;
            next();
        });
    }

// Routes
//new feature:
app.get('/', (req, res) => {
    // Render the welcome.hbs view
    res.render('welcome');
});
//The belowone is new route
app.post('/api/register', (req, res) => {
    const { email, password } = req.body;
    const newUser = new User(email, password);
    users.push(newUser);
    res.status(201).json({ message: 'User registered successfully' });
});
//this one is also new one
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    // Find user by email
    const user = users.find(user => user.email === email);

    // If user doesn't exist or password doesn't match, send error response
    if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid email or password' });
    }

    // If user exists and password matches, generate JWT token
    const accessToken = generateAccessToken({ email: user.email });

    // Send JWT token to client
    res.json({ accessToken: accessToken });
});







// POST /api/restaurants
app.post('/api/restaurants', [
    check('name').notEmpty().withMessage('Name is required'),
   
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const restaurant = await db.addNewRestaurant(req.body);
        res.json(restaurant);
    } catch (error) {
        console.error('Error creating restaurant:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// GET /api/restaurants
app.get('/api/restaurants', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const perPage = parseInt(req.query.perPage) || 10;
        const borough = req.query.borough || null;
        

        const restaurants = await db.getAllRestaurants(page, perPage, borough);
        res.json(restaurants);
    } catch (error) {
        console.error('Error getting restaurants:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// GET /api/restaurants/search
app.all('/api/restaurants/search', async (req, res) => {
    if (req.method === 'GET') {
        // Render the form for GET requests
        res.render('restaurants-search-form');
    } else if (req.method === 'POST') {
        // Process form data for POST requests
        const { page, perPage, borough } = req.body;
        const currentPage = parseInt(page);
        const itemsPerPage = parseInt(perPage);
        
        try {
            const restaurants = await db.getAllRestaurants(currentPage, itemsPerPage, borough);
            console.log('Fetched restaurants:', restaurants);
            console.log('Submitted borough:', borough);

            // Render the results using Handlebars template engine
            res.render('restaurants-search-results', { restaurants, currentPage, perPage, borough });
        } catch (error) {
            console.error('Error fetching restaurants:', error);
            res.status(500).json({ message: 'Internal server error' });
        }
    }
});


// GET /api/restaurants/:id
app.get('/api/restaurants/:id', async (req, res) => {
    try {
        const restaurant = await db.getRestaurantById(req.params.id);
        if (!restaurant) {
            return res.status(404).json({ message: 'Restaurant not found' });
        }
        res.json(restaurant);
    } catch (error) {
        console.error('Error getting restaurant by ID:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// PUT /api/restaurants/:id
app.put('/api/restaurants/:id', async (req, res) => {
    try {
        const restaurant = await db.updateRestaurantById(req.body, req.params.id);
        if (!restaurant) {
            return res.status(404).json({ message: 'Restaurant not found' });
        }
        res.json({ message: 'Restaurant updated successfully', data: restaurant });
    } catch (error) {
        console.error('Error updating restaurant by ID:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// DELETE /api/restaurants/:id
app.delete('/api/restaurants/:id', async (req, res) => {
    try {
        const result = await db.deleteRestaurantById(req.params.id);
        if (!result) {
            return res.status(404).json({ message: 'Restaurant not found' });
        }
        res.json({ message: 'Restaurant deleted successfully' });
    } catch (error) {
        console.error('Error deleting restaurant by ID:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

module.exports = app;
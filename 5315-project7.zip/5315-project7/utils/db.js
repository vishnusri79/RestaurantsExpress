

const mongoose = require('mongoose');
const Restaurant = require('../models/RestaurantModel');

// Function to initialize MongoDB connection and Restaurant model
async function initialize(connectionString) {
    try {
        await mongoose.connect(connectionString, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('MongoDB connected');
    } catch (error) {
        console.error('MongoDB connection error:', error);
        throw error;
    }
}

// Function to add a new restaurant
async function addNewRestaurant(data) {
    try {
        return await Restaurant.create(data);
    } catch (error) {
        console.error('Error adding new restaurant:', error);
        throw error;
    }
}

// Function to get all restaurants with pagination and optional borough filter
async function getAllRestaurants(page, perPage, borough) {
    try {
        let query = Restaurant.find().sort('_id').skip((page - 1) * perPage).limit(perPage);
        if (borough) {
            query = query.where('borough').equals(borough);
        }
        return await query.exec();
    } catch (error) {
        console.error('Error getting all restaurants:', error);
        throw error;
    }
}


// Function to get a restaurant by ID
async function getRestaurantById(id) {
    try {
        return await Restaurant.findById(id).exec();
    } catch (error) {
        console.error('Error getting restaurant by ID:', error);
        throw error;
    }
}

// Function to update a restaurant by ID
async function updateRestaurantById(data, id) {
    try {
        return await Restaurant.findByIdAndUpdate(id, data, { new: true }).exec();
    } catch (error) {
        console.error('Error updating restaurant by ID:', error);
        throw error;
    }
}

// Function to delete a restaurant by ID
async function deleteRestaurantById(id) {
    try {
        return await Restaurant.findByIdAndDelete(id).exec();
    } catch (error) {
        console.error('Error deleting restaurant by ID:', error);
        throw error;
    }
}

module.exports = {
    initialize,
    addNewRestaurant,
    getAllRestaurants,
    getRestaurantById,
    updateRestaurantById,
    deleteRestaurantById
};

// authUtils.js
const jwt = require('jsonwebtoken');

const secretKey = '12345';

// Generate JWT token with consistent secret key
function generateAccessToken(user) {
    return jwt.sign(user, secretKey, { expiresIn: '1h' });
}



module.exports = {
    generateAccessToken
};

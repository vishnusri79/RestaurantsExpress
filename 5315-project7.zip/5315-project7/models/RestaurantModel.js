

const mongoose = require('mongoose');

const RestaurantSchema = new mongoose.Schema({
    name: String,
    cuisine: String,
    address: {
        street: String,
        city: String,
        state: String,
        zipcode: String
    },
    borough: String,
    grades: [{
        date: Date,
        grade: String,
        score: Number
    }]
});

const Restaurant = mongoose.model('Restaurant', RestaurantSchema);

module.exports = Restaurant;
